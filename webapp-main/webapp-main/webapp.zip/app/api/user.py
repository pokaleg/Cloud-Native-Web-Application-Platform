from fastapi import APIRouter, Request, Response, Depends, HTTPException
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from app.core.database import get_db
from app.core.security import hash_password
from app.models.user import User
from app.schemas.user import UserCreate, UserUpdate, UserResponse

router = APIRouter()
security = HTTPBasic()

def get_current_user(credentials: HTTPBasicCredentials = Depends(security), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == credentials.username.lower()).first()
    if not user or not user.check_password(credentials.password):
        raise HTTPException(
            status_code=401,
            detail="Authentication credentials are missing or invalid"
        )
    return user

@router.post("/v1/user", status_code=201, response_model=UserResponse)
async def create_user(request: Request, user_data: UserCreate, response: Response, db: Session = Depends(get_db)):
    # Check if user exists
    existing_user = db.query(User).filter(User.username == user_data.username.lower()).first()
    if existing_user:
        raise HTTPException(
            status_code=409,
            detail="A user with this email address already exists"
        )
    
    try:
        # Create user
        user = User(
            username=user_data.username.lower(),
            password=hash_password(user_data.password),
            first_name=user_data.first_name,
            last_name=user_data.last_name
        )
        db.add(user)
        db.commit()
        db.refresh(user)
        
        # Set Location header
        response.headers["Location"] = "/v1/user/self"
        
        return user
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="A user with this email address already exists"
        )

@router.get("/v1/user/self", response_model=UserResponse)
def get_user(current_user: User = Depends(get_current_user)):
    return current_user

@router.put("/v1/user/self", status_code=204)
def update_user(
    request: Request,
    user_update: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Get update data
    update_data = user_update.model_dump(exclude_unset=True)
    
    # Update fields
    if 'first_name' in update_data and update_data['first_name'] is not None:
        current_user.first_name = update_data['first_name']
    if 'last_name' in update_data and update_data['last_name'] is not None:
        current_user.last_name = update_data['last_name']
    if 'password' in update_data and update_data['password'] is not None:
        current_user.password = hash_password(update_data['password'])
    
    db.commit()
    return Response(status_code=204)
