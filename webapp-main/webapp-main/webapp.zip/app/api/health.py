from fastapi import APIRouter, Request, Depends
from fastapi.responses import Response
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.user import HealthCheck

router = APIRouter()

@router.get("/healthz")
async def health_check(request: Request, db: Session = Depends(get_db)):
    """
    Health check endpoint
    Returns: 200 if healthy, 400 if bad request, 405 if wrong method, 503 if unhealthy
    """
    # Common headers for all responses
    headers = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "X-Content-Type-Options": "nosniff"
    }
    
    # Check for query parameters
    if request.query_params:
        return Response(content="", status_code=400, headers=headers, media_type="text/plain")
    
    # Check for request body
    body = await request.body()
    if body:
        return Response(content="", status_code=400, headers=headers, media_type="text/plain")
    
    # Try to perform database health check
    try:
        health = HealthCheck()
        db.add(health)
        db.commit()
        return Response(content="", status_code=200, headers=headers, media_type="text/plain")
    except Exception:
        db.rollback()
        return Response(content="", status_code=503, headers=headers, media_type="text/plain")

@router.api_route("/healthz", methods=["POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"])
async def health_not_allowed():
    """Handle unsupported methods for health check"""
    headers = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "X-Content-Type-Options": "nosniff"
    }
    return Response(content="", status_code=405, headers=headers, media_type="text/plain")
